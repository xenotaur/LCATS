"""LCATS mass-quantities story parser using Gettenberg acquisition and
metadata, with the established metadata-aware Gutenberg narrative extractor.

The caller supplies a configured Gettenberg GutenbergStorySource; it owns the
catalog lifetime and network/cache policy. No deprecated gettenberg.api calls.
"""

import dataclasses
import os
import pathlib
import re

from lcats import constants
from lcats.utils import names
from lcats.gatherers import normalization, story_output
from lcats.analysis.corpus import discovery
from lcats.gatherers.mass_quantities import storymap
from lcats.gatherers.mass_quantities.gutenberg_extractor import clean_gutenberg_story

def possible_internal_chapter_name(line):
    if line.strip().isupper() and len(line.strip().split(" ")) < 7:
        if line.strip()[0] == '"' and line.strip()[-2:] == '."':
            return False
        if line.strip()[0] == '"' and line.strip()[-1:] == '"':
            return False
        if line.strip()[-1:] == ":":
            return False
        if line.strip()[0] == "\“" and line.strip()[-1:] == "\”":
            return False
        #        if line.strip() == "THE END.":
        #            return False
        if line.strip()[0] == "_" and line.strip()[-1:] == "_":
            return False
        if not any(
            exception == line.strip() for exception in storymap.TITLE_EXCEPTIONS
        ):
            return True

    return False

def chaptered(text):
    """Return True if the text contains chapters, False otherwise.

    Works for chapters in Roman numerals and w/o names.   Needs to be expanded.

    Args:
        text (str): The full text of the story.
    Returns:
        bool: True if the text contains chapters, False otherwise.
    """
    result = 0

    possible_titles = 0

    text_array = text.split("\n\n")

    # if several lines are simply all caps, then it's probably chapter names
    multiple_lines_all_caps = False
    for index, line in enumerate(text_array):
        if possible_internal_chapter_name(line):
            if index < len(text_array) - 2 and text_array[index + 1].isupper():
                multiple_lines_all_caps = True
            elif index > 0 and text_array[index - 1].isupper():
                multiple_lines_all_caps = True
            else:
                multiple_lines_all_caps = False

            # if index < len(text_array) - 2:
            #    multiple_lines_all_caps = True
            # else:
            #    multiple_lines_all_caps = False

            if not multiple_lines_all_caps:
                if index == 0:
                    possible_titles = possible_titles + 1
                else:
                    if (
                        len(text_array[index - 1]) > 0
                        and text_array[index - 1][-1] != ":"
                    ):
                        possible_titles = possible_titles + 1
                    else:
                        possible_titles = possible_titles + 1

        line = line.strip().lower()

        if line in ["table of contents", "contents", "contents.", "contents:"]:
            return True

        if line.startswith("i ~"):
            result = result + 1
        if line.startswith("ii ~"):
            result = result + 1
        if line.startswith("iii ~"):
            result = result + 1

        if line.startswith("i."):
            result = result + 1
        if line.startswith("ii."):
            result = result + 1
        if line.startswith("iii."):
            result = result + 1

        if line.startswith("chapter "):
            result = result + 1

        if line in [
            "i",
            "i.",
            "chapter i",
            "chapter 1",
            "chapter i.",
            "chapter one",
            "chap. i.",
            "part i",
            "part i.",
        ]:
            result = result + 1
        if line in [
            "ii",
            "ii.",
            "chapter ii",
            "chapter 2",
            "chapter two",
            "chapter ii.",
            "chap. ii.",
            "part ii",
            "part ii.",
        ]:
            result = result + 1
        if line in [
            "iii",
            "iii.",
            "chapter iii",
            "chapter 3",
            "chapter three",
            "chapter iii.",
            "chap. iii.",
            "part iii",
            "part iii.",
        ]:
            result = result + 1

    # A single I or II might be an anomoly so this is to see if both exist

    if result == 0 and possible_titles == 2:
        return False
    else:
        return result >= 2 or possible_titles >= 2

def author_ok(author):
    """Return True if the author is consistent with what we want.

    Args:
        author (frozenset): A frozenset representing the author from the metadata of the story.
    Returns:
        bool: True if the author is consistent with what we want, False otherwise.
    """
    return len(list(author)) > 0

def subject_ok(subject):
    """Return True if the subject is consistent with what we want (short fiction).

    Args:
        subject (frozenset): a string or list of strings representing the subject from the story metadata.
    Returns:
        bool: True if the subject appears to be short fiction, False otherwise.
    """

    if bad_subjects(subject):
        return False

    if loc_fiction(subject) and (short_story(subject) or fiction(subject)):
        return True

    return False

def bad_subjects(subjects):
    """Return True if the subject contains a bad topic (currently just epistolary)
    Args:
        subjects (frozenset): The subject from the gutenberg metadata.
    Returns:
        bool:  True if identified as bad, False otherwse
    """

    for subject in subjects:
        for bad_subject in storymap.EXCLUDED_SUBJECTS:
            if bad_subject in subject.lower():
                return True

    return False

def fiction(subject):
    """Return True if the subject contains fiction
    Args:
        subjects (frozenset): The subject from the gutenberg metadata.
    Returns:
        bool:  True if identified as fiction, False otherwse
    """

    for piece in list(subject):
        if "fiction" in piece.lower().strip():
            return True

    return False


def short_story(subject):
    """Return True if the subject contains a short story tag
    Args:
        subjects (frozenset): The subject from the gutenberg metadata.
    Returns:
        bool:  True if identified as a short story / short stories, False otherwse
    """

    for piece in list(subject):
        if "short stor" in piece.lower().strip():
            return True

    return False

def loc_fiction(subject):
    """Return True if the subject contains a fiction tag via library of congress keys
    Args:
        subjects (frozenset): The subject from the gutenberg metadata.
    Returns:
        bool:  True if identified as a PS or PR library of congress tag, False otherwse
    """

    for piece in list(subject):
        if piece in ["PS", "PR"]:
            return True

    return False

def story_excluded(story_id):
    """Return True if OK to try this story, False otherwise"""
    return story_id in storymap.STORIES_TO_EXCLUDE

def only_english(languages, target="en"):
    """Return True if the only language is the target language (default "en" for English).

    Args:
        languages (list or set): A list or set of language codes (e.g., ["en", "fr"])
            presumably from the metadata of a Gutenberg story.
        target (str): The target language code to check against (default is "en").
    Returns:
        bool: True if the only language is the target language, False otherwise.
    """
    if target not in languages:
        return False
    other_languages = set(languages)
    other_languages.remove(target)
    return not other_languages

def title_ok(title):
    """Return True if the title is consistent with a valid story.

    Args:
        title (list[str]): A list of titles to check.

    Returns:
        bool: True if the title is consistent with what we want, False otherwise.
    """

    result = True
    if len(title) > 1:  # multiple titles
        for a_title in title:
            result = result and title_ok([a_title])

        return result

    if "; and" in title[0].strip().lower():
        return False

    if ", and" in title[0].split("\n")[0].strip().lower():
        return False

    if "index of the project gutenberg" in title[0].lower():
        return False

    for part_indicator in storymap.EXCLUDED_TITLE_PART_WORDS:
        if re.search(rf"{part_indicator}\s*\d+", title[0], re.IGNORECASE):
            return False

    for piece in title[0].split(" "):
        piece = piece.lower()

        if piece in storymap.EXCLUDED_TITLE_WORDS:
            return False

    return True




def _metadata_rejection(metadata, story):
    """Apply the shared gathering and inspection eligibility rules without I/O."""
    if metadata is None or not metadata.subjects:
        return "No data for this story, skipping"
    if not metadata.titles:
        return "No title for this story, skipping"
    if not all(
        (
            subject_ok(metadata.subjects),
            only_english(metadata.languages),
            title_ok(metadata.titles),
            author_ok(metadata.authors),
        )
    ):
        return "Metadata not suitable, skipping."
    if story_excluded(story):
        return "Story on exclusion list, skipping."
    return None


def _inspect_metadata(story, metadata, source):
    """Build the same deterministic extraction report used by gather_story."""
    report = {
        "gutenberg_id": story,
        "metadata": (
            None
            if metadata is None
            else {
                "titles": list(metadata.titles),
                "authors": list(metadata.authors),
                "aliases": list(metadata.aliases),
                "subjects": list(metadata.subjects),
                "languages": list(metadata.languages),
            }
        ),
        "rejection": _metadata_rejection(metadata, story),
        "body": None,
        "provenance": None,
    }
    if report["rejection"] is not None:
        return report
    prepared = source.read(metadata)
    # Physical newlines remain intact in the original-byte cache. Normalize only
    # at the paragraph parser boundary, matching the historical extraction rules.
    text = prepared.cleaned.text.replace("\r\n", "\n").replace("\r", "\n").strip()
    # Preserve the established LCATS narrative extractor, while obtaining
    # source text and catalog metadata through the new Gettenberg API.
    body = clean_gutenberg_story(
        text,
        title=list(metadata.titles),
        authors=list(metadata.authors),
        pseudonyms=list(metadata.aliases),
        remove_the_end=True,
    )
    report["body"] = body
    report["provenance"] = prepared.provenance()
    if chaptered(body):
        report["rejection"] = "Story has chapters, skipping."
    elif len(body.split("\n\n")) <= 10:
        report["rejection"] = "Story is too short, skipping."
    return report


def inspect_story(story, *, source):
    """Return JSON-compatible metadata, body, rejection and source provenance.

    This replaces the notebook/debug helpers that printed partial results and
    silently fetched metadata or text. The caller supplies a GutenbergStorySource
    and owns its catalog lifetime and network policy. Rejected metadata causes no
    acquisition. Eligible text may be cached according to that explicit policy;
    no story output is written. Operational errors propagate, not eligibility
    rejections. A rejected short/chaptered story retains its body for inspection.
    """
    return _inspect_metadata(story, source.metadata(story), source)


@dataclasses.dataclass(frozen=True)
class StoryGatherResult:
    """One extraction outcome; reused outputs have not been requalified.

    disposition is written, reused or skipped. A published path is not evidence
    of a new source download: writing may also use an already cached source.
    """

    story: int
    path: str | None
    rejection: str | None
    disposition: str


def gather_story(gatherer, story, *, source):
    """Return the historical (ID, saved/existing path, rejection) tuple."""
    result = gather_story_result(gatherer, story, source=source)
    return result.story, result.path, result.rejection


def gather_story_result(gatherer, story, *, source):
    """Extract and atomically publish a story using an explicit source.

    Args:
        gatherer: DataGatherer owning the output collection directory.
        story: Positive Gutenberg ebook ID.
        source: GutenbergStorySource with a pinned catalog and explicit policy.

    Returns:
        StoryGatherResult distinguishing a new write, output reuse or exclusion.
        Source, decoding, cleanup and output errors propagate to the run boundary.
        An existing regular output is reused before source acquisition; its content
        is not revalidated.
    """
    metadata = source.metadata(story)
    rejection = _metadata_rejection(metadata, story)
    if rejection is not None:
        return StoryGatherResult(story, None, rejection, "skipped")
    title = metadata.titles[0]
    author = list(metadata.authors)
    file_name = names.title_and_author_to_filename(
        title, author, ext=constants.FILE_SUFFIX, max_len=50
    )
    story_slug = os.path.splitext(file_name)[0]
    existing = (
        pathlib.Path(gatherer.path) / story_slug / discovery.CANONICAL_STORY_FILENAME
    )
    if story_output.existing(existing):
        return StoryGatherResult(story, str(existing), None, "reused")
    report = _inspect_metadata(story, metadata, source)
    if report["rejection"] is not None:
        return StoryGatherResult(story, None, report["rejection"], "skipped")
    data_to_save = {
        "name": title,
        "author": author,
        "body": report["body"],
        "metadata": {
            "author": author,
            "year": "Unknown",
            "url": report["provenance"]["source_uri"],
            "name": file_name,
            "gettenberg": report["provenance"],
        },
    }
    # Reuse the same replayable repairs and bucket slug as previous gathering.
    normalization.normalize_story_dict(
        data_to_save, collection=storymap.TARGET_DIRECTORY, story_id=story_slug
    )
    _, file_path = gatherer.ensure(story_slug)
    written = story_output.publish(file_path, data_to_save)
    return StoryGatherResult(story, file_path, None, "written" if written else "reused")
